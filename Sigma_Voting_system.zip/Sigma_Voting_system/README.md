# Online Voting System for Elections
 It is a desktop application made with socket programming in Python. It uses synchronous multithreading. 
 
 For details on this project, please read the <a href="https://github.com/shah-deep/Online-Voting-System/blob/main/Report.pdf">Report</a>.
